# Rajomon-HTTP - Source Code

**COL724 / COL7524 Advanced Computer Networks**
Suraj Raj (2026MCS2801) - Siddhesh Pohare (2026MCS2257)

Rajomon-HTTP brings Rajomon-style token-and-price admission control (originally gRPC-only) to REST/HTTP microservices. A small Go **sidecar** reverse proxy sits in front of each service, reads the `X-Rajomon-Tokens` header, computes a congestion price, and either forwards the request or sheds it - with **no change to the protected application**. The benchmark app is **TeaStore** (5 REST/HTTP Spring Boot microservices).

```
price = base_price + scale_factor x (queued + in_flight)      cost = ceil(price)
```

| Tokens header | tokens vs ceil(price) | Verdict | HTTP | Upstream touched |
|---|---|---|---|---|
| missing / invalid | - | RejectMissingTokens | 401 | No |
| present | tokens >= cost | Forward (tokens -= cost) | 200 | Yes |
| present | tokens < cost | RejectInsufficientTokens | 503 | No |

## Contents

```
3_Source_Code/
  sidecar/                  Go sidecar (the contribution)
    main.go                 /healthz, /metrics, admission + reverse proxy
    admission.go            Decide(), AdmissionCost() (math.Ceil)
    pricing.go              atomic Queued/InFlight counters, GetLocalPrice()
    headers.go              Read/Write token + price headers
    metrics.go              Prometheus counter, gauges, price histogram
    config.go               RAJOMON_* environment configuration
    admission_test.go       16 unit sub-tests
    Dockerfile, go.mod, go.sum
  benchmark-app/            TeaStore compose stack (included by root compose)
  gateway-config/           Envoy configs: permissive (passes header) / hardened (strips it)
  monitoring/               Prometheus scrape config + Grafana provisioning and fleet dashboard
  load-tests/               wrk Lua scripts and PowerShell/bash test scripts
  docker-compose.yml        Full stack: TeaStore + 5 sidecars + Envoy + Prometheus + Grafana
  .env.example              Tunable parameters
```

## Requirements

- Docker Desktop (Docker Compose v2.20+ for the `include:` directive)
- About 6 GB free RAM (TeaStore JVMs are heavy); ~60 s warm-up after start
- No local Go install needed - tests run in a container

## Run

```bash
cp .env.example .env
docker compose --profile permissive up -d      # or: --profile hardened
# wait ~60 s for TeaStore, then:
curl http://localhost:9550/healthz             # ok  (ports 9550-9554 = 5 sidecars)

# FORWARD  -> 200 + X-Rajomon-Price: 1.50
curl -si -H "X-Rajomon-Tokens: 100" http://localhost:9550/tools.descartes.teastore.webui/
# REJECT insufficient -> 503
curl -si -H "X-Rajomon-Tokens: 0"   http://localhost:9550/tools.descartes.teastore.webui/
# REJECT missing token -> 401
curl -si http://localhost:9550/tools.descartes.teastore.webui/
# tokens=1 < ceil(1.5)=2 -> 503
curl -si -H "X-Rajomon-Tokens: 1"   http://localhost:9550/tools.descartes.teastore.webui/
# Through the Envoy gateway (header survival, permissive profile) -> 200
curl -si -H "X-Rajomon-Tokens: 100" http://localhost:10000/tools.descartes.teastore.webui/

docker compose --profile permissive down       # stop (add -v to reset volumes)
```

### Unit tests (16 sub-tests)

```bash
docker run --rm -v "${PWD}/sidecar:/src" -w /src golang:1.26 sh -c "go test ./... -v"
```

### Load tests

```bash
# Spike: 200 connections, tokens=50, 30 s (price exceeds budget -> ~100% 503)
docker run --rm --network host williamyeh/wrk -t8 -c200 -d30s \
  -H "X-Rajomon-Tokens: 50" http://localhost:9550/tools.descartes.teastore.webui/

# Full scenario suite (PowerShell)
./load-tests/phase6-load-test.ps1
```

## Configuration (`.env`)

| Variable | Default | Meaning |
|---|---|---|
| `RAJOMON_BASE_PRICE` | 1.0 | Minimum price at zero load |
| `RAJOMON_PRICE_SCALE_FACTOR` | 0.5 | Price increase per active request |
| `GF_SECURITY_ADMIN_USER` / `_PASSWORD` | admin / rajomon | Grafana login |
| `ENVOY_GATEWAY_PORT`, `ENVOY_ADMIN_PORT` | 10000, 9901 | Envoy ports |

## Ports

8080 TeaStore WebUI - 9550-9554 sidecars (webui, auth, imageprovider, recommender, persistence) - 10000 Envoy - 9901 Envoy admin - 9090 Prometheus - 3000 Grafana (admin / rajomon)

## Prometheus metrics

`rajomon_sidecar_requests_total{verdict}`, `rajomon_sidecar_queued_requests`, `rajomon_sidecar_in_flight_requests`, `rajomon_sidecar_admission_price` (histogram). Example: `rate(rajomon_sidecar_requests_total[1m])`.

## Results summary (single-laptop Docker run, Nov 2026)

| Check | Result |
|---|---|
| Sidecar health (5/5), five-verdict curl checks, unit tests | All pass (16/16 sub-tests) |
| Price vs load (tokens=50) | First rejection at N=99 concurrent (price 50.50, cost 51) |
| Spike: 200 conn, tokens=50, 30 s | 514,442 requests at 17,117 req/s; 514,536 rejected (100%), 101 forwarded; queued and in-flight return to 0 |
| Forward, 20 conn, tokens=100 | 468 req/s, 77 ms avg |
| Forward spike, 100 conn, tokens=100 | 292 req/s, 221 ms avg |
| Rejection fast path (tokens=1), 100 conn | 68,302 req/s, 2.93 ms avg, upstream untouched |
| Missing-token path (401), 20 conn | 40,390 req/s, 1.17 ms avg, upstream untouched |
| Envoy header survival | Permissive: PASS. Hardened: header stripped, sidecar rejects with 401 |

These are laptop-scale results, directionally consistent with the design but not comparable in absolute terms to the original paper's cluster measurements.

## Design notes

- **Zero app changes:** sidecars own the `teastore-<name>` Docker network alias; real services run as `teastore-<name>-upstream`, so internal calls pass through admission automatically.
- **Three policy decisions:** strict 401 on missing token (no fail-open), combined `queued + in_flight` congestion signal, `ceil(price)` charge.
- **Price header:** injected via `ReverseProxy.ModifyResponse` plus a request-context value (setting it after `ServeHTTP` is silently lost).
- **History:** the project first targeted DeathStarBench Social Network, which speaks Apache Thrift (not HTTP) between services, so it was replaced by TeaStore.
